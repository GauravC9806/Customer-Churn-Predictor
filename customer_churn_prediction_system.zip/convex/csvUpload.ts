import { mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const uploadCsvData = mutation({
  args: {
    customers: v.array(v.any())
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    // Clear existing data
    const existingCustomers = await ctx.db.query("customers").collect();
    for (const customer of existingCustomers) {
      await ctx.db.delete(customer._id);
    }

    let successCount = 0;
    let errorCount = 0;

    for (const customerData of args.customers) {
      try {
        const normalizedCustomer = {
          customerId: customerData.customerID || customerData.customerId || `CUST_${Date.now()}_${successCount}`,
          gender: customerData.gender || "Unknown",
          seniorCitizen: customerData.SeniorCitizen === 1 || customerData.SeniorCitizen === "1" || customerData.seniorCitizen === true,
          partner: customerData.Partner === "Yes" || customerData.partner === true,
          dependents: customerData.Dependents === "Yes" || customerData.dependents === true,
          tenure: parseInt(customerData.tenure) || 0,
          phoneService: customerData.PhoneService === "Yes" || customerData.phoneService === true,
          multipleLines: customerData.MultipleLines || customerData.multipleLines || "No",
          internetService: customerData.InternetService || customerData.internetService || "No",
          onlineSecurity: customerData.OnlineSecurity || customerData.onlineSecurity || "No",
          onlineBackup: customerData.OnlineBackup || customerData.onlineBackup || "No",
          deviceProtection: customerData.DeviceProtection || customerData.deviceProtection || "No",
          techSupport: customerData.TechSupport || customerData.techSupport || "No",
          streamingTV: customerData.StreamingTV || customerData.streamingTV || "No",
          streamingMovies: customerData.StreamingMovies || customerData.streamingMovies || "No",
          contract: customerData.Contract || customerData.contract || "Month-to-month",
          paperlessBilling: customerData.PaperlessBilling === "Yes" || customerData.paperlessBilling === true,
          paymentMethod: customerData.PaymentMethod || customerData.paymentMethod || "Electronic check",
          monthlyCharges: parseFloat(customerData.MonthlyCharges || customerData.monthlyCharges) || 0,
          totalCharges: parseFloat(customerData.TotalCharges || customerData.totalCharges) || 0,
          churn: customerData.Churn === "Yes" || customerData.churn === true,
          lastUpdated: Date.now(),
        };

        await ctx.db.insert("customers", normalizedCustomer);
        successCount++;
      } catch (error) {
        console.error("Error inserting customer:", error);
        errorCount++;
      }
    }

    return { 
      message: `CSV data uploaded successfully`, 
      successCount, 
      errorCount,
      totalProcessed: args.customers.length 
    };
  },
});
